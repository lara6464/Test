var express = require('express');
const axios = require('axios');
var router = express.Router();
const db=require('../db');
const mysql=require('mysql');


router.post('/sign', function(req, res, next) {
  const { name,age,gender, email,password } = req.body;
  const query = 'INSERT INTO netapp (name,age,gender, email,password) VALUES (?, ?, ?, ?, ?)';
  db.query(query, [name,age,gender, email,password], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      res.status(500).send('Database error');
    } else {
      res.redirect('/nethome');
    }
  });
});

// router.post('/note', function(req, res, next) {
//   const { date,task,priority,status,additional } = req.body;
//   const query = 'INSERT INTO tsknote (date,task,priority,status,additional ) VALUES (?, ?, ?, ?, ?)';
//   db.query(query, [date,task,priority,status,additional ], (err, result) => {
//     if (err) {
//       console.error('Error inserting data:', err);
//       res.status(500).send('Database error');
//     } else {
//       res.redirect('/task');
//     }
//   });
// });



// router.post('/login', function(req, res, next) {
//   const {email,password} = req.body;
//   const query = 'INSERT INTO todolist (email, password) VALUES (?, ?)';
//   db.query(query, [email,password ], (err, result) => {
//     if (err) {
//       console.error('Error inserting data:', err);
//       res.status(500).send('Database error');
//     } else {
//       res.redirect('/todo');
//     }
//   });
// });



var bcrypt = require('bcrypt');
const saltRounds = 10;

router.post('/pass', function(req, res, next) {
  const {email, password } = req.body;
  bcrypt.hash(password, saltRounds, function(err, hash) {
    if (err) {
      console.error('Error encrypting password:', err);
      res.status(500).send('Server error');
      return;
    }
    const query = 'INSERT INTO netapp (email, password) VALUES (?, ?)';
    db.query(query, [email, hash], (err, results) => {
      if (err) {
        console.error('Error inserting data:', err);
        res.status(500).send('Database error');
      } else {
        res.redirect('/netinside');
      }
    });
  });
});





router.post('/log', function(req, res, next) {
  const {email, password } = req.body;
  bcrypt.hash(password, saltRounds, function(err, hash) {
    if (err) {
      console.error('Error encrypting password:', err);
      res.status(500).send('Server error');
      return;
    }
    const query = 'INSERT INTO netapp (email, password) VALUES (?, ?)';
    db.query(query, [email, hash], (err, results) => {
      if (err) {
        console.error('Error inserting data:', err);
        res.status(500).send('Database error');
      } else {
        res.redirect('/netinside');
      }
    });
  });
});


// router.post('/lezgo', (req, res) => {
//   const { email, password } = req.body;
//   const query = 'SELECT * FROM todolist WHERE email = ?';
//   db.query(query, [email], (err, results) => {
//     if (err) {
//       console.error('Error querying the database:', err);
//       return res.status(500).send('Server error');
//     }

//     if (results.length === 0) {
//       return res.status(401).send('User not found');
//     }

//     const user = results[0];
//     bcrypt.compare(password, user.password, (err, isMatch) => {
//       if (err) {
//         console.error('Error comparing passwords:', err);
//         return res.status(500).send('Server error');
//       }

//       if (!isMatch) {
//         return res.status(401).send('Invalid email or password');
//       }
//       req.session.user = { id: user.id};
//       res.redirect('/todo');
//     });
//   });
// });

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Welcome to EXPRESS' ,title2: 'This is another title',message:'This is a message'});
});
// router.get('/nethome', function(req, res, next) {
//   res.render('nethome');
// });
router.get('/login', function(req, res, next) {
  res.render('testlogin');
});
router.get('/netsign', function(req, res, next) {
  res.render('netsign');
});
router.get('/netsearch', function(req, res, next) {
  res.render('netsearch');
});
router.get('/netuser', function(req, res, next) {
  res.render('netuser');
});




//api


const TMDB_API_KEY = 'a783322050ac0a94836b82d510a5a785';

router.get('/nethome', async (req, res) => {
  try {
    const response = await axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${TMDB_API_KEY}&language=en-US&page=1`);
    const movies = response.data.results;
    res.render('nethome', { movies });
  } catch (error) {
    console.error('Error fetching movies:', error);
    res.status(500).send('Error fetching movies');
  }
});

router.get('/nettv', async (req, res) => {
  try {
    const popularresponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={us}`);
    const popular = popularresponse.data.results;
    const watchresponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={chinese}`);
    const watch = watchresponse.data.results;
    const comedyresponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={comedy}`);
    const comedy = comedyresponse.data.results;
    const dramaresponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={dramas}`);
    const drama = dramaresponse.data.results;
    const youresponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={spiderman}`);
    const you = youresponse.data.results;
    res.render('nettv', { popular,watch,comedy,drama,you });
  } catch (error) {
    console.error('Error fetching movies:', error);
    res.status(500).send('Error fetching movies');
  }
});



router.get('/netinside', async (req, res) => {
  try {
    // Fetch popular movies
    const moviesResponse = await axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${TMDB_API_KEY}&language=en-US&page=1`);
    const movies = moviesResponse.data.results;
    
    // Fetch Marvel-related movies
    const marvelResponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={Anime}`);
    const marvel = marvelResponse.data.results;

    const indiaResponse = await axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${TMDB_API_KEY}&query={indian}`);
    const india = indiaResponse.data.results;

    // Render the page with both movie lists
    res.render('netinside', { movies, marvel ,india});
  } catch (error) {
    console.error('Error fetching movies:', error);
    res.status(500).send('Error fetching movies');
  }
});




// router.get('/task', function(req, res, next) {
//   const query = 'SELECT date, task, priority, status, additional,id FROM tsknote'; 
//   db.query(query, (err, results) => {
//     if (err) {
//       console.error('Error fetching data:', err);
//       res.status(500).send('Database error');
//     } else {
//       res.render('task', { table: results });
//     }
//   });
// });



// router.get('/edit/:id', function(req, res, next) {
//   const userId = req.params.id;
//  const query = 'SELECT * FROM tsknote WHERE id = ?';
//  db.query(query, [userId], (err, results) => {
// if (err) {
// console.error('Error fetching data:', err);
// res.status(500).send('Database error');
// } else if (results.length === 0) {
// res.status(404).send('User not found');
// } else {
//   res.render('edittask', { note: results[0] });
// }
// });
// });


// router.post('/update/:id', function(req, res, next) {
// const userId = req.params.id;
// const { date,task,priority,status,additional} = req.body;
// const query = 'UPDATE tsknote SET date = ?, task= ?,priority= ?, status = ?, additional= ? WHERE id = ?';

// db.query(query, [date,task,priority,status,additional, userId], (err, results) => {
// if (err) {
// console.error('Error updating data:', err);
// res.status(500).send('Database error');
// } else {
// res.redirect('/task');
// }
// });
// });


// router.get('/delete/:id', (req, res) => {
//   const userId = req.params.id; 
//   const query = 'DELETE FROM tsknote WHERE id = ?';

//   db.query(query, [userId], (err, results) => {
//     if (err) {
//       console.error('Error deleting user:', err);
//       return res.status(500).send('Database error');
//     }
//     res.redirect('/task');
//   });
// });




router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error during logout:', err);
      return res.status(500).send('Logout failed');
    }
    
    res.redirect('/nethome');
  });
});


// router.get('/api', async (req, res) => {
//   try {
//     const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
//     const posts = response.data;
//     res.render('api', { title: 'api', posts });
//   } catch (error) {
//     console.error('Error fetching data:', error);
//     res.status(500).send('Error fetching api');
//   }
// });


// router.get('/api2', async (req, res) => {
//   try {
//     const response = await axios.get('https://jsonplaceholder.typicode.com/users');
//     const posts = response.data;
//     res.render('api2', { title: 'Users', posts });
//   } catch (error) {
//     console.error('Error fetching data:', error);
//     res.status(500).send('Error fetching posts');
//   }
// });

// router.get('/apicard', async (req, res) => {
//   try {
//     const response = await axios.get('https://fakestoreapi.com/products');
//     const products = response.data;
//     res.render('apicard', { title: 'Products', products });
//   } catch (error) {
//     console.error('Error fetching data:', error);
//     res.status(500).send('Error fetching posts');
//   }
// });

module.exports = router;
